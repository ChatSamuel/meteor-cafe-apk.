# Meteor Café — status do desenvolvimento

**Etapa atual: estrutura dedicada criada; ainda sem compilação do APK.**

## Concluído nesta etapa

- [x] Extração local do código-fonte J2ME-Loader fornecido no pacote de engenharia reversa.
- [x] Criação do flavor Android `meteor` com identificador de pacote exclusivo.
- [x] Inclusão do JAR original como asset do aplicativo.
- [x] Launcher dedicado que converte o JAR para DEX no primeiro início e inicia o MIDlet diretamente.
- [x] Verificação SHA-256 para impedir que um arquivo errado ou corrompido seja executado.
- [x] Perfil padrão inicial de 240×320, orientação retrato, toque ativo, proporção preservada e filtro de imagem desligado.
- [x] Documentação do processo e dos avisos de licenciamento.

## Bloqueios técnicos do ambiente atual

1. Android SDK e Android NDK não estão instalados neste ambiente.
2. O wrapper solicita Gradle 9.6.0, mas o ambiente não consegue acessar `services.gradle.org` para baixá-lo.
3. O ZIP do código-fonte contém o diretório do submódulo TinySoundFont vazio; o código C++ de áudio MIDI inclui `tsf.h`, portanto o submódulo precisa ser restaurado antes da compilação nativa.
4. O APK ainda não foi compilado, instalado nem executado no Galaxy A05.

## Próximas etapas

1. Restaurar TinySoundFont e sincronizar Gradle/SDK/NDK no Android Studio.
2. Compilar `meteorDebug` e corrigir eventuais incompatibilidades de build.
3. Instalar no Galaxy A05 e testar inicialização, desenho, toque, áudio e salvamento.
4. Ajustar escala, orientação, latência, áudio e interface conforme os resultados reais.
5. Gerar uma versão Release assinada somente após a aprovação dos testes e esclarecimento das permissões de distribuição.

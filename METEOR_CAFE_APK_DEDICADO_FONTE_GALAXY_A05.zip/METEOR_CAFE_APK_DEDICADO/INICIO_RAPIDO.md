# Meteor Café — projeto Android dedicado

O diretório `vendor/J2ME-Loader` contém o projeto Android modificado. Abra essa pasta no Android Studio quando o ambiente de compilação estiver preparado.

**Variante a compilar:** `meteorDebug`  
**Pacote Android:** `com.apk.engineering.meteorcafe`  
**Jogo integrado:** MeteorCafe 1.18.0  
**Resolução lógica configurada:** 240 × 320 (proporção original preservada)

Antes de compilar, leia `vendor/J2ME-Loader/README_METEOR_CAFE.md` e restaure o submódulo TinySoundFont pelo script adequado ao seu sistema. O APK ainda não foi gerado nem validado em aparelho; esta entrega é a primeira versão do código-fonte dedicado.

Os relatórios `METEOR_CAFE_AUDITORIA_*.md` documentam o arquivo original e os achados técnicos da análise estática.

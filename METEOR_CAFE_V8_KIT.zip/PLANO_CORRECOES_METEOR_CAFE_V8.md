# Meteor Cafe — V8: rotação automática e refinamento dos controles

## Base utilizada
Projeto-fonte derivado da versão V7 que passou pela compilação GitHub Actions #9.

## Alterações aplicadas

### 1. Orientação automática
- `ProfileModel.orientation` passou de `2` (portrait) para `1` (auto), que no `MicroActivity` deste projeto equivale a `SCREEN_ORIENTATION_FULL_SENSOR`.
- Removida a chamada do launcher que forçava `SCREEN_ORIENTATION_PORTRAIT`.
- Removido `android:screenOrientation="portrait"` da atividade de inicialização no Manifest do flavor `meteor`.
- O `MicroActivity` já declara `configChanges` para `orientation`, `screenSize`, `screenLayout` e `smallestScreenSize`.
- `Canvas.ViewCallbacks.surfaceChanged()` atualiza a largura e a altura reais da superfície e chama `updateSize()`. O cálculo da escala e a conversão dos toques usam a nova área efetiva.

### 2. Compatibilidade paisagem sem deformar o jogo
- Mantida a resolução lógica fixa de 240 × 320 do MIDlet.
- Mantido `Fit` com proporção original, centralização e escala de 100%.
- Em paisagem, a área jogável permanece na orientação original (retrato) e fica centralizada na tela horizontal; o fundo suavizado preenche o espaço lateral. Isso permite girar e continuar jogando sem girar textos ou controles de lado.
- Esta versão oferece rotação funcional, mas não redesenha o jogo em um layout nativo 16:9. Uma reorganização real de mesas, clientes, HUD e botões exigiria reestruturar a interface interna do MIDlet.

### 3. Fundo adaptativo à orientação
- O fundo desfocado invalida o cache quando a largura ou altura real da superfície muda.
- O recorte é recalculado pela proporção atual do aparelho: faixa vertical em retrato e faixa panorâmica em paisagem.
- O bitmap antigo é liberado antes de criar o novo, dentro do mesmo `bufferLock` usado pela renderização.

### 4. Botões coloridos
- O ponto de posicionamento da fileira de quatro botões passou de Y=276 para Y=284 no JAR ajustado.
- O ajuste anterior já havia movido a fileira de Y=268 para Y=276. O deslocamento acumulado em relação ao JAR original é, portanto, +16 pixels virtuais.
- A posição é definida por `n.a(index, x, y)`. Para os elementos com tipo de posição `2`, esse método atualiza a posição do objeto `bh`; os métodos `n.u()` e `n.v()` leem a mesma posição, e a rotina `n.h()` usa essa posição ao calcular as áreas de interação. Assim, o desenho e a região de toque acompanham o deslocamento.
- O ajuste ainda precisa ser avaliado visualmente e com toques reais no Galaxy A05. A distância até a barra inferior deve ser observada para garantir que não haja sobreposição.

## Integridade do jogo
- O JAR original permanece preservado em `original/meteor_cafe_original.jar`.
- SHA-256 do JAR original: `a621bf0e11046aabb4ddcaa9c0c3d3a3aefa9340a415c2ce690ef977a394f8c6`.
- SHA-256 do JAR incorporado V8: `99d91a52fc3b4fc0340b6761639aacd98de6b3c5e5bfdce0dab991047c00910a`.
- Em relação ao JAR V7, a única entrada alterada dentro do arquivo é `a.class`, com a constante de posição Y alterada de 276 para 284. Os demais itens do JAR V7 foram preservados.

## Verificações realizadas nesta preparação
- XML do Manifest parseado com sucesso.
- Bytecode de `a.class` inspecionado com `javap`; a constante é 284.
- SHA-256 do JAR recalculado e atualizado no launcher e no workflow V8.
- Integridade do ZIP verificada.
- Workflow V8 usa a configuração da compilação que passou na execução #9, atualizando a verificação SHA-256 e o nome do artefato.

## O que ainda precisa ser testado no aparelho
1. Girar o aparelho para paisagem e confirmar que o Android muda a orientação.
2. Verificar se a tela de jogo continua inteira e centralizada, sem cortes.
3. Testar os quatro botões, arrasto/toque, pausa e atendimento em retrato e paisagem.
4. Confirmar se o fundo lateral muda de recorte depois da rotação.
5. Avaliar se a fileira de botões em Y=284 ficou mais afastada das mesas sem encostar na barra de progresso.
6. Testar a rotação durante uma partida, não apenas antes de iniciar.

## Limites da validação
Estas alterações foram preparadas e verificadas estaticamente. Não foi executada uma nova compilação Android neste ambiente. A confirmação final depende do GitHub Actions e do teste no Galaxy A05.

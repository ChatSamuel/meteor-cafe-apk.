# Meteor Cafe V8 — atualização para Galaxy A05

## O que esta versão altera
- Permite rotação automática entre retrato e paisagem (sensor completo).
- Mantém a tela lógica original do jogo em 240 × 320, sem esticar os sprites.
- Recalcula o fundo desfocado quando a orientação muda.
- Mantém o jogo vertical e centralizado dentro da tela horizontal; as laterais são preenchidas com fundo adaptado.
- Desloca a fileira dos quatro botões mais 8 pixels virtuais em relação à V7 (total de +16 px em relação ao JAR original), incluindo suas áreas de toque.
- Preserva uma cópia intacta do JAR original.

## Arquivos
- `METEOR_CAFE_APK_DEDICADO_FONTE_GALAXY_A05_V8_UPLOAD.zip`: projeto atualizado.
- `build-meteor-v8.txt`: workflow para colar no GitHub pelo celular.
- `build-meteor-v8.yml`: a mesma configuração em arquivo YAML.
- `PLANO_CORRECOES_METEOR_CAFE_V8.md`: resumo técnico e testes necessários.

## Atualizar GitHub sem excluir arquivos antigos
1. Abra o repositório privado `ChatSamuel/meteor-cafe-apk`.
2. Na aba Code, selecione Add file → Upload files.
3. Envie o arquivo `METEOR_CAFE_APK_DEDICADO_FONTE_GALAXY_A05_V8_UPLOAD.zip` para a raiz do repositório. Não é necessário apagar os ZIPs antigos.
4. Abra `.github/workflows/build-meteor.yml`, toque no lápis e substitua todo o conteúdo pelo `build-meteor-v8.txt`.
5. Faça Commit changes.
6. Abra Actions → Compilar Meteor Cafe → Run workflow.
7. O artefato esperado se chamará `Meteor-Cafe-APK-V8-debug`.

## Testes no Galaxy A05
1. Ative rotação automática nas configurações rápidas do Android.
2. Abra Meteor Cafe em retrato e confirme menus, gameplay e controles.
3. Gire para paisagem e aguarde a tela se recompor.
4. Teste os quatro botões, a pausa, o arrasto e os pedidos nas duas orientações.
5. Volte para retrato e verifique se o layout retorna corretamente.
6. Observe se os botões não se sobrepõem à barra inferior.

## Limite funcional da V8
A rotação do telefone passa a ser permitida, mas a interface original do MIDlet continua em retrato, em proporção 240 × 320, centralizada em uma tela horizontal. As áreas laterais são preenchidas pelo fundo dinâmico. Isso NÃO é um redesenho nativo do jogo em 16:9. Uma interface horizontal verdadeira requer redesign de mesas, clientes, HUD e controles, e deverá ser uma fase posterior.

## Validação
As alterações foram verificadas por inspeção estática, verificação de XML, hashes, bytecode e integridade do ZIP. A V8 ainda precisa ser compilada no GitHub Actions e testada fisicamente no Galaxy A05. Não considerar pronta para distribuição até esses testes terminarem e os direitos de distribuição serem esclarecidos.
